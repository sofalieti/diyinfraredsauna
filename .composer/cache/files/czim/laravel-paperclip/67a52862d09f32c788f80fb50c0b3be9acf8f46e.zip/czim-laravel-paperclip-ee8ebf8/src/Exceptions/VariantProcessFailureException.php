<?php
namespace Czim\Paperclip\Exceptions;

class VariantProcessFailureException extends \Exception
{
}
