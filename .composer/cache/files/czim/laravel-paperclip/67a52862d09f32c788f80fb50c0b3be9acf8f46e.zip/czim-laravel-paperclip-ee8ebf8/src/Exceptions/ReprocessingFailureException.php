<?php
namespace Czim\Paperclip\Exceptions;

class ReprocessingFailureException extends \Exception
{
}
