<?php
namespace Czim\FileHandling\Test;

abstract class TestCase extends \PHPUnit\Framework\TestCase
{
}
