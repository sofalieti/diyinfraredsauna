<?php
namespace Czim\FileHandling\Exceptions;

use Exception;

abstract class AbstractFileHandlingException extends Exception
{
}
