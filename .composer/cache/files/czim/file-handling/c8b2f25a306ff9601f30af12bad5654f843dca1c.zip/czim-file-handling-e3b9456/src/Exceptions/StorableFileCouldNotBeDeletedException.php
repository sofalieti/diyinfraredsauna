<?php

namespace Czim\FileHandling\Exceptions;

use RuntimeException;

class StorableFileCouldNotBeDeletedException extends RuntimeException
{
}
