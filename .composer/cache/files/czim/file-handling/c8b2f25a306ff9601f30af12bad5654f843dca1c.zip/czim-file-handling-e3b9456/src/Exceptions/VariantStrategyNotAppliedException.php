<?php
namespace Czim\FileHandling\Exceptions;

class VariantStrategyNotAppliedException extends AbstractFileHandlingException
{
}
