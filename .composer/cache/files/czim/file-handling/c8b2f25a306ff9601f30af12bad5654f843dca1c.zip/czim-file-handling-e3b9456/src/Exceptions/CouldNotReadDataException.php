<?php
namespace Czim\FileHandling\Exceptions;

class CouldNotReadDataException extends AbstractFileHandlingException
{
}
