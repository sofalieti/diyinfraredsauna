<?php
namespace Czim\FileHandling\Exceptions;

class CouldNotRetrieveRemoteFileException extends AbstractFileHandlingException
{
}
