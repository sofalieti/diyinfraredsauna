<?php
namespace Czim\FileHandling\Exceptions;

class FileStorageException extends AbstractFileHandlingException
{
}
