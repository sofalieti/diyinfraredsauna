<?php
namespace Czim\FileHandling\Exceptions;

class VariantStrategyShouldNotBeAppliedException extends AbstractFileHandlingException
{
}
