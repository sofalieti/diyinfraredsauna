<?php
namespace Czim\FileHandling\Exceptions;

class CouldNotProcessDataException extends AbstractFileHandlingException
{
}
