<?php

namespace Encore\Admin\Form\Field;

use Encore\Admin\Form\Field;

class Id extends Field
{
}
