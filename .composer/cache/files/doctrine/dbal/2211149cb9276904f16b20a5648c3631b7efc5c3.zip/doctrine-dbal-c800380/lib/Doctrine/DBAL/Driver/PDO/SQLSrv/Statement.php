<?php

namespace Doctrine\DBAL\Driver\PDO\SQLSrv;

use Doctrine\DBAL\Driver\PDOSqlsrv;

final class Statement extends PDOSqlsrv\Statement
{
}
